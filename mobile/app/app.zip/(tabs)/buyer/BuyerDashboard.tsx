import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function BuyerDashboard() {
  const router = useRouter();

  /* Reusable Card */
  const Card = ({ title, onPress }: any) => (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Text style={styles.cardText}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>

      {/* Header */}
      <Text style={styles.title}>🛒 Buyer Dashboard</Text>
      <Text style={styles.subtitle}>Buy recyclable materials easily</Text>

      {/* Grid */}
      <View style={styles.grid}>

        <Card title="🛍 Marketplace" />

        <Card title="📦 My Orders" />

        <Card title="📊 Purchase History" />

        <Card title="💳 Payments" />

        <Card title="⭐ Favorites" />

        {/* ⭐ PROFILE BUTTON */}
        <Card
          title="👤 Profile"
          onPress={() => router.push('/(tabs)/buyer/BuyerProfile')}
        />

        {/* ⭐ LOGOUT */}
        <Card
          title="🚪 Logout"
          onPress={() => router.replace('/(tabs)/Login')}
        />

      </View>
    </ScrollView>
  );
}

/* ================= STYLES ================= */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEF2F3',
    paddingHorizontal: 20,
    paddingTop: 70,
  },

  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#2F5D34',
  },

  subtitle: {
    color: '#6B7280',
    marginBottom: 25,
  },

  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  card: {
    width: '48%',
    height: 120,
    backgroundColor: '#2F5D34',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
    elevation: 4,
  },

  cardText: {
    color: '#FFFFFF',
    fontWeight: '600',
    textAlign: 'center',
  },
});
