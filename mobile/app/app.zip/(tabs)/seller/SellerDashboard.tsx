import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function SellerDashboard() {
  const router = useRouter();

  /* Dashboard Card */
  const Card = ({ title, onPress }: any) => (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Text style={styles.cardText}>{title}</Text>
    </TouchableOpacity>
  );

  /* Alert Example */
  const showAlert = () => {
    Alert.alert(
      'Smart Bin Alert',
      'Your plastic bin is almost full!',
      [{ text: 'OK' }]
    );
  };

  return (
    <ScrollView style={styles.container}>

      {/* Header */}
      <Text style={styles.title}>♻️ Seller Dashboard</Text>
      <Text style={styles.subtitle}>
        Manage your smart bins & recyclable waste
      </Text>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>120kg</Text>
          <Text style={styles.statLabel}>Waste Sold</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statNumber}>Rs.45K</Text>
          <Text style={styles.statLabel}>Earnings</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statNumber}>18</Text>
          <Text style={styles.statLabel}>Orders</Text>
        </View>
      </View>

      {/* Grid Buttons */}
      <View style={styles.grid}>

        <Card title="🗑 Bin Status" />

        <Card
          title="📦 Sell Waste"
          onPress={() => router.push('/(tabs)/seller/AddWaste')}
        />

        <Card
          title="📋 Orders"
          onPress={() => router.push('/(tabs)/seller/SellerOrders')}
        />

        <Card title="📊 Reports" />

        <Card title="🔔 Alerts" onPress={showAlert} />

        <Card
          title="👤 Profile"
          onPress={() => router.push('/(tabs)/seller/SellerProfile')}
        />

        <Card
          title="🚪 Logout"
          onPress={() => router.replace('/(tabs)/Login')}
        />

      </View>
    </ScrollView>
  );
}

/* ================= STYLES ================= */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F7F3',
    paddingHorizontal: 20,
    paddingTop: 60,
  },

  title: {
    fontSize: 26,
    fontWeight: '800',
    color: '#2F5D34',
  },

  subtitle: {
    color: '#6B7280',
    marginBottom: 20,
  },

  /* Stats */

  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 25,
  },

  statCard: {
    backgroundColor: '#FFFFFF',
    width: '31%',
    padding: 14,
    borderRadius: 14,
    alignItems: 'center',
    elevation: 3,
  },

  statNumber: {
    fontSize: 18,
    fontWeight: '700',
    color: '#4F772D',
  },

  statLabel: {
    fontSize: 12,
    color: '#6B7280',
  },

  /* Grid */

  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  card: {
    width: '48%',
    height: 110,
    backgroundColor: '#4F772D',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
    elevation: 4,
  },

  cardText: {
    color: '#FFFFFF',
    fontWeight: '600',
    textAlign: 'center',
    fontSize: 14,
  },
});