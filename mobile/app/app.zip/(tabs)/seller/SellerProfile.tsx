import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function SellerProfile() {
  const router = useRouter();

  const Row = ({ label, value }: any) => (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );

  return (
    <View style={styles.container}>

      {/* Avatar */}
      <Image
        source={require('../../../assets/images/logo.png')}
        style={styles.avatar}
      />

      <Text style={styles.name}>Seller Account</Text>
      <Text style={styles.role}>Role: Seller</Text>

      <View style={styles.card}>
        <Row label="Email" value="seller@gmail.com" />
        <Row label="Bins Managed" value="12" />
        <Row label="Total Sales" value="Rs. 45,000" />
      </View>

      <TouchableOpacity
        style={styles.logout}
        onPress={() => router.replace('/(tabs)/Login')}
      >
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F9F4',
    alignItems: 'center',
    paddingTop: 70,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    marginBottom: 10,
  },
  name: {
    fontSize: 20,
    fontWeight: '700',
  },
  role: {
    color: '#4F772D',
    marginBottom: 20,
  },
  card: {
    width: '85%',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    elevation: 4,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  label: {
    color: '#6B7280',
  },
  value: {
    fontWeight: '600',
  },
  logout: {
    marginTop: 30,
    backgroundColor: '#4F772D',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 25,
  },
  logoutText: {
    color: '#fff',
    fontWeight: '600',
  },
});
